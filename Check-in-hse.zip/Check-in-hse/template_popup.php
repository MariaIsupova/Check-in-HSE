<div class="modal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-header">
            <a href="#" class="btn-close closemodal" aria-hidden="true">&times;</a>
             инфрмация о лекции 
            Информация о лекции/стенде
            <? print($lecture['title']);?>
        </div>

        <div class="modal-body">
            <input type="text" name="code" placeholder="введите код">
            <div class="modal-footer">
                <!--<input class="btn" name="register" value="Подтвердить" , type="submit">-->
                <a href="#" class="btn">Подтвердить</a>
            </div>
        </div>
    </div>
</div>