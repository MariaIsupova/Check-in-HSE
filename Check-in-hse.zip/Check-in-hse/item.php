<div class="event"  onclick="location.href='/lectures.php?id_meetup=<?=$item['id_meetup'];?>' ">
    <p class=" name"><?=$item['title'];?></p> 
    <div class="dec"></div>
    <div>
        <p class=" name"><?=$item['date'];?></p>
    </div>
</div>
